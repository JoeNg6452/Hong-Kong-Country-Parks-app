package hkmu.comps380f.project.Controller;

import hkmu.comps380f.project.dao.AdminService;
import hkmu.comps380f.project.exception.BookNotFound;
import hkmu.comps380f.project.exception.ComNotFound;
import hkmu.comps380f.project.exception.UserNotFound;
import hkmu.comps380f.project.Model.Comment;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {
    @Resource
    AdminService adServ;

    @GetMapping({"","/","/userlist"})
    public String list(ModelMap model){
        model.addAttribute("users",adServ.getUsers());
        return "listUser";
    }

    public static class UserForm {
        private String username;
        private String password;
        private String email;
        private String phone;
        private String address;
        private String[] roles;

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getPhone() {
            return phone;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public String[] getRoles() {
            return roles;
        }

        public void setRoles(String[] roles) {
            this.roles = roles;
        }
    }

    // Using path ./admin/userlist
    // User CRUD
    @GetMapping("/create")
    public ModelAndView createUser(){
        return new ModelAndView("addUser","user",new UserForm());
    }

    @PostMapping("/create")
    public String create(UserForm form) throws IOException {
        adServ.createUser(form.getUsername(), form.getPassword(),
                form.getEmail(),form.getPhone(),
                form.getAddress(),form.getRoles());
        return "redirect:/admin/userlist";
    }

    @GetMapping("/delete/{username}")
    public String deleteUser(@PathVariable("username") String username)
            throws UserNotFound {
        adServ.deleteUser(username);
        return "redirect:/admin/userlist";
    }

    public static class ComForm {
        private String username;
        private String bookTitle;
        private String comment;

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getBookTitle() {
            return bookTitle;
        }

        public void setBookTitle(String bookTitle) {
            this.bookTitle = bookTitle;
        }

        public String getComment() {
            return comment;
        }

        public void setComment(String comment) {
            this.comment = comment;
        }
    }

    // Comments page using path ./admin/comments
    // Comments CRUD
    @GetMapping("/comments")
    public String listComments(ModelMap model){
        model.addAttribute("comments",adServ.getComments());
        return "listComments";
    }

    @GetMapping("/addCom")
    public ModelAndView addComments(){
        return new ModelAndView("commentManage","comments",new ComForm());
    }

    @PostMapping("/addCom")
    public String addCom(ComForm form) throws UserNotFound,BookNotFound {
        adServ.addCom(form.getUsername(), form.getBookTitle(), form.getComment());
        return "redirect:/admin/comments";
    }

    @PostMapping("/delCom/{id}")
    public String delCom(@PathVariable("id") int id) throws ComNotFound{
        adServ.delCom(id);
        return "redirect:/admin/comments";
    }

    // Item page
    // Availability change
    @GetMapping("/availSwap/{title}")
    public String availSwap(@PathVariable("title") String title) throws BookNotFound {
        adServ.changeAvail(title);
        return "redirect:/itemList";
    }

    public static class BookForm{
        private String title;
        private String author;
        private String description;
        private float price;
        private boolean available;
        private byte[] cover;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public byte[] getCover() {
            return cover;
        }

        public void setCover(byte[] cover) {
            this.cover = cover;
        }

        public boolean isAvailable() {
            return available;
        }

        public void setAvailable(boolean available) {
            this.available = available;
        }

        public float getPrice() {
            return price;
        }

        public void setPrice(float price) {
            this.price = price;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getAuthor() {
            return author;
        }

        public void setAuthor(String author) {
            this.author = author;
        }
    }

    // Book CRUD
    @PostMapping("/createBook")
    public String createBook(BookForm form){
        adServ.addBook(form.getTitle(),form.getAuthor(),form.getDescription(),
                form.getPrice(),form.isAvailable(),form.getCover());
        return "redirect:/admin/itemList";
    }

    @PostMapping("/updateBook")
    public String updateBook(BookForm form, List<Comment> comment)
            throws BookNotFound{
        adServ.updateBook(form.getTitle(),form.getAuthor(),form.getDescription(),
                form.getPrice(),form.isAvailable(),comment,form.getCover());
        return "redirect:/admin/itemList";
    }

    @GetMapping("/deleteBook/{title}")
    public String deleteBook(@PathVariable("title") String title)
            throws BookNotFound{
        adServ.delBook(title);
        return "redirect:/admin/itemList";
    }
}
