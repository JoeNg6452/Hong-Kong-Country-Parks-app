package hkmu.comps380f.project.Controller;

import hkmu.comps380f.project.Model.Book;
import org.apache.coyote.Request;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Controller
@RequestMapping("/store")
public class BookStoreController {
    private volatile long Book_ID_SEQUENCE = 1;
    private Map<Long, Book> bookDatabase = new ConcurrentHashMap<>();
    @GetMapping(value = {"", "/index"})
    public String list(ModelMap model) {
        model.addAttribute("bookDatabase", bookDatabase);
        return "index";
    }

    @GetMapping("/itemPage")
    public String itemPage(){
        return "itemPage";
    }

    @GetMapping("/shoppingCart")
    public String shoppingCart(){
        return "shoppingCart";
    }

    @GetMapping("/orderHistory")
    public String orderHistory(){
        return "orderHistory";
    }

    @GetMapping("/myFavourite")
    public String myFavourite(){
        return "myFavourite";
    }


}
