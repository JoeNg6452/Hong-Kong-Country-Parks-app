package hkmu.comps380f.project.Controller;

import hkmu.comps380f.project.dao.CartManagementService;
import hkmu.comps380f.project.dao.UserManagementService;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;
import java.security.Principal;

@Controller
@RequestMapping("/cart")
public class CartManagementController {
    @Resource
    private CartManagementService cmService;

    public static class item {
        private String bookname;

        public item(String bookname) {}
    }

    @GetMapping({"/shoppingCart"})
    public String list(ModelMap model, Principal principal) {
        String username = principal.getName();
        model.addAttribute("Cart", cmService.getCart(username));
        return "shoppingCart";
    }

    @PostMapping("/addItem")
    public String addItem(ModelMap model, Principal principal) {

    }
}
