package hkmu.comps380f.project.Controller;

import hkmu.comps380f.project.Model.BookStoreUser;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.ui.Model;


@Controller
public class IndexController {
    @GetMapping("/")
    public String index(){
        return "redirect:/store/index";
    }

    @GetMapping("/login")
        public String login() {
            return "login";
    }

    @GetMapping("/registration")
    public String registrationForm(Model model){
        return "RegistrationPage";
    }

    @PostMapping("/registration")
    public String registration(){
        return "redirect:/login";
    }

}
