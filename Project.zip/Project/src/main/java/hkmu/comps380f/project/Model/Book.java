package hkmu.comps380f.project.Model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="book")
public class Book {

    @Id
    private String title;
    private String author;
    private String description;
    private float price;
    private boolean availability;

    @OneToMany(mappedBy = "title",fetch = FetchType.EAGER,
    cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Comment> comments = new ArrayList<>();

    private byte[] coverPhotos;

    public Book(){}
    public Book(String title, String author, String description,
                float price, boolean availability, byte[] coverPhotos) {
        this.title = title;
        this.author = author;
        this.description = description;
        this.price = price;
        this.availability = availability;
        this.coverPhotos = coverPhotos;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isAvailability() {
        return availability;
    }

    public void setAvailability(boolean availability) {
        this.availability = availability;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public byte[] getCoverPhotos() {
        return coverPhotos;
    }

    public void setCoverPhotos(byte[] coverPhotos) {
        this.coverPhotos = coverPhotos;
    }

    public List<Comment> getComments() {
        return comments;
    }

    public void setComments(List<Comment> comments) {
        this.comments = comments;
    }
}
