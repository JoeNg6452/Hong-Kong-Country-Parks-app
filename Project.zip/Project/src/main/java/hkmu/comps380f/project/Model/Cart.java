package hkmu.comps380f.project.Model;

import jakarta.persistence.*;

import hkmu.comps380f.project.Model.Book;
import java.util.Map;

public class Cart {
    @Id
    private String username;
    private Map<Book, Integer> books;

    public Cart(String username, Map books) {
        this.username = username;
        this.books = books;
    }

    public String getUsername() {return username;}

    public void setUsername(String username) {this.username = username;}

    public Map getBookList() {return books;}

    public void addBook(Book book, int num) {
        if (this.books.containsKey(book)) {this.books.replace(book, this.books.get(book)+num);}
        else{this.books.put(book, num);}
    }

    public void removeBook(Book book, int num) {
        this.books.replace(book, this.books.get(book)-num);
        if (this.books.get(book) <= 0) {this.books.remove(book);}
    }

    public void setBookList(Map books) {this.books = books;}
}
