package hkmu.comps380f.project.Model;

import jakarta.persistence.*;

@Entity
@Table(name="comments")
public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String comment;

    @Column(name="title",insertable=false, updatable=false)
    private String bookTitle;
    @Column(name="name",insertable=false, updatable=false)
    private String username;

    @ManyToOne
    @JoinColumn(name="title")
    private Book book;

    @ManyToOne
    @JoinColumn(name="name")
    private User user;

    public Comment(){}
    public Comment(String comment, Book book, User user) {
        this.comment = comment;
        this.book = book;
        this.user = user;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
