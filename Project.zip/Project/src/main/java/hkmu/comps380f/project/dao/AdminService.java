package hkmu.comps380f.project.dao;

import hkmu.comps380f.project.exception.BookNotFound;
import hkmu.comps380f.project.exception.ComNotFound;
import hkmu.comps380f.project.exception.UserNotFound;
import hkmu.comps380f.project.Model.Book;
import hkmu.comps380f.project.Model.Comment;
import hkmu.comps380f.project.Model.User;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AdminService {
    @Resource
    private UserRepository userRepo;
    private BookRepository bookRepo;
    private CommentRepository comRepo;

    //User CRUD
    @Transactional
    public List<User> getUsers() {
        return userRepo.findAll();
    }

    @Transactional
    public User getUser(String username)
            throws UserNotFound{
        User user = userRepo.findById(username).orElse(null);
        if (user == null) {
            throw new UserNotFound(username);
        }
        return user;
    }

    @Transactional(rollbackFor = UserNotFound.class)
    public void deleteUser(String username) throws UserNotFound {
        User deletedUser = userRepo.findById(username).orElse(null);
        if (deletedUser == null) {
            throw new UserNotFound(username);
        }
        userRepo.delete(deletedUser);
    }

    @Transactional
    public void createUser(String username,String password,String email,
                           String phone,String address,String[] roles) {
        User newUser = new User(username,password,email,phone,address,roles);
        userRepo.save(newUser);
    }

    @Transactional
    public void updateUser(String username,String password,String email,
                           String phone,String address,String[] roles)
            throws UserNotFound {
        //delete the current one first
        User user = userRepo.findById(username).orElse(null);
        if (user == null) {
            throw new UserNotFound(username);
        }
        userRepo.delete(user);
        //save a user with updated attributes
        User updatedUser = new User(username,password,email,phone,address,roles);
        userRepo.save(updatedUser);
    }

    //Comment CRUD
    @Transactional
    public void addCom(String username, String title, String comment)
            throws BookNotFound,UserNotFound {
        User user = userRepo.findById(username).orElse(null);
        Book book = bookRepo.findById(title).orElse(null);
        if (book == null) {
            throw new BookNotFound(title);
        } else if (user == null) {
            throw new UserNotFound(username);
        }
        Comment newComment = new Comment(comment, book, user);
        comRepo.save(newComment);
    }

    @Transactional
    public List<Comment> getComments() {
        return comRepo.findAll();
    }

    @Transactional
    public void delCom(int id)
            throws ComNotFound {
        Comment comment = comRepo.findById(id).orElse(null);
        if (comment == null) {
            throw new ComNotFound(id);
        }
        comRepo.delete(comment);
    }

    //Book availability CRUD
    @Transactional
    public void changeAvail(String title) throws BookNotFound {
        Book selectedBook = bookRepo.findById(title).orElse(null);
        if (selectedBook == null) {
            throw new BookNotFound(title);
        }
        boolean avail = selectedBook.isAvailability();
        selectedBook.setAvailability(!avail);
        bookRepo.save(selectedBook);
    }

    //Item CRUD
    @Transactional
    public void addBook(String title, String author, String description,
                        float price, boolean availability,
                        byte[] coverPhotos){
        Book newBook = new Book(title,author,description,price,availability,coverPhotos);
        bookRepo.save(newBook);
    }

    @Transactional
    public void delBook(String title) throws BookNotFound {
        Book selectedBook = bookRepo.findById(title).orElse(null);
        if (selectedBook == null) {
            throw new BookNotFound(title);
        }
        bookRepo.delete(selectedBook);
    }

    @Transactional
    public void updateBook(String title, String author, String description,
                           float price, boolean availability,
                           List<Comment> comments, byte[] coverPhotos)
            throws BookNotFound {
        //delete the current book first
        Book selectedBook = bookRepo.findById(title).orElse(null);
        if (selectedBook == null) {
            throw new BookNotFound(title);
        }
        bookRepo.delete(selectedBook);
        //save the book with updated attributes
        Book newBook = new Book(title,author,description,price,availability,coverPhotos);
        newBook.setComments(comments);
        bookRepo.save(newBook);
    }
}
