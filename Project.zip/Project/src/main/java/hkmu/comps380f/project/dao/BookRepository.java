package hkmu.comps380f.project.dao;

import hkmu.comps380f.project.Model.Book;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookRepository extends JpaRepository<Book, String> {
}
