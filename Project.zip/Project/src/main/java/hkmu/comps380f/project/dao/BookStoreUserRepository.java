package hkmu.comps380f.project.dao;

import hkmu.comps380f.project.Model.BookStoreUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookStoreUserRepository extends JpaRepository<BookStoreUser, String> {
}
