package hkmu.comps380f.project.dao;

import hkmu.comps380f.project.Model.Cart;
import hkmu.comps380f.project.Model.StoreUser;
import hkmu.comps380f.project.Model.Book;
import jakarta.annotation.Resource;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class CartManagementService {
    @Resource
    private CartRepository cartRepo;

    @Transactional
    public List<Cart> getAllCarts() {return cartRepo.findAll();}

    @Transactional
    public Map getCart(String username) {
        Cart cart = cartRepo.findById(username).orElse(null);
        return cart.getBookList();
    }

    @Transactional
    public void deleteItem(String username, Book book, int num) {
        Cart cart = cartRepo.findById(username).orElse(null);
        cart.removeBook(book, num);
        cartRepo.save(cart);
    }

    public void addItem(String username, Book book, int num) {
        Cart cart = cartRepo.findById(username).orElse(null);
        cart.addBook(book, num);
        cartRepo.save(cart);
    }

    @Transactional
    public void createCart(String username) {
        Map books = new ConcurrentHashMap();
        Cart cart = new Cart(username, books);
        cartRepo.save(cart);
    }

    @Transactional
    public void deleteCart(String username) {
        Cart cart = cartRepo.findById(username).orElse(null);
        cartRepo.delete(cart);
    }
}
