package hkmu.comps380f.project.dao;

import hkmu.comps380f.project.Model.Cart;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CartRepository extends JpaRepository<Cart, String> {
}
