package hkmu.comps380f.project.dao;

import hkmu.comps380f.project.Model.StoreUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StoreUserRepository extends JpaRepository<StoreUser, String> {
}
