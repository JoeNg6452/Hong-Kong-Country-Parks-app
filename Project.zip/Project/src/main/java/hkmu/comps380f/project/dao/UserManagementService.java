package hkmu.comps380f.project.dao;

import hkmu.comps380f.project.Model.StoreUser;
import jakarta.annotation.Resource;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UserManagementService {
    @Resource
    private StoreUserRepository suRepo;

    @Transactional
    public List<StoreUser> getStoreUsers() {
        return suRepo.findAll();
    }

    @Transactional
    public void delete(String username) {
        StoreUser StoreUser = suRepo.findById(username).orElse(null);
        if (StoreUser == null) {
            throw new UsernameNotFoundException("User '" + username + "' not found.");
        }
        suRepo.delete(StoreUser);
    }

    @Transactional
    public void createStoreUser(String username, String password, String name, String email, String address, String[] roles) {
        StoreUser user = new StoreUser(username, password, name, email, address, roles);
        suRepo.save(user);
    }
}
