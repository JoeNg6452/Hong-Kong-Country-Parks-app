package hkmu.comps380f.project.dao;

import hkmu.comps380f.project.Model.UserRole;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRoleRepository extends JpaRepository<UserRole, Integer> {
}
