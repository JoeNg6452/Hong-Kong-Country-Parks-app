package hkmu.comps380f.project.exception;

public class ComNotFound extends Exception{
    public ComNotFound(String title,String name){
        super("Comment from "+title+" By "+name+" does not exist");
    }
    public ComNotFound(int id){
        super("Comment "+id+" does not exist");
    }
}
