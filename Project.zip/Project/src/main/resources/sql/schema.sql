
create table if not exists book (
                                    title varchar(255),
    author varchar(255),
    description LONGTEXT,
    price DOUBLE,
    availability BOOLEAN,
    comments LONGTEXT,
    coverPhoto blob,
    primary key (title)
    );
create table if not exists users (
                                     name varchar(50) NOT NULL,
    password varchar(50) NOT NULL,
    email varchar(255) NOT NULL,
    phone varchar(8),
    address varchar(4096),
    primary key (name)
    );
create table if not exists user_roles (
                                          user_role_id int generated always as identity,
                                          name varchar(50) not null,
    role varchar(50) not null,
    primary key (user_role_id),
    foreign key (name) references users(name
    );
create table if not exists comments(
                                       comment_id int generated always as identity,
                                       comment LONGTEXT,
                                       name varchar(50),
    title varchar(255),
    primary key (comment_id),
    foreign key (name) references users(name),
    foreign key (title) references book(title)
    );
create table if not exists orderHist(
                                        name varchar(50),
    title varchar(255),
    orderDate datetime,
    foreign key (name) references users(name),
    foreign key (title) references book(title)
    );
